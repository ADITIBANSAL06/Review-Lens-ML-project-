from flask import Flask, jsonify, render_template, request,send_file,send_from_directory
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from module import file_Upload,performSearch

app = Flask(__name__)

# Initialize VADER sentiment analyzer
sid = SentimentIntensityAnalyzer()

@app.route('/')
def homepage():
    return render_template('index.html')

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    # if request.method == 'POST':
        file = request.files['file']
        if file:
            # Save the file
            file.save("static/"+file.filename)
            return jsonify({'message': f'{"static/"+file.filename};;;1'}), 200
    # return render_template('index.html')

@app.route('/file')
def fileRoute():
    # Getting and Opening the file
    file = request.args.get('name')
    file = open("static/"+file,encoding="utf-8")
    # getting the column name
    column_name = request.args.get('column')
    # calling the functions
    graph_html,updated_csv_path,df_preview,sentiment_counts = file_Upload(file,column_name,sid)
    return render_template('result.html', graph_html=graph_html,csv_file=updated_csv_path,df_preview=df_preview, positive=sentiment_counts["Positive"],negative=sentiment_counts["Negative"],neutral=sentiment_counts["Neutral"])

@app.route('/search')
def searchRoute():
    topic = request.args.get('topic')
    graph_html,updated_csv_path,df_preview,sentiment_counts = performSearch(topic)
    return render_template('result.html', graph_html=graph_html,csv_file=updated_csv_path,df_preview=df_preview, positive=sentiment_counts["Positive"],negative=sentiment_counts["Negative"],neutral=sentiment_counts["Neutral"])


@app.route('/load')
def loadingRoute():
    return render_template('load.html')


@app.route('/download')
def download_file():
    print("here comes it")
    filename = request.args.get('filename')
    # Adjust the path based on where your files are stored
    return send_file(filename, as_attachment=True)


if __name__ == '__main__':
    app.run(debug=True, port=8000)

