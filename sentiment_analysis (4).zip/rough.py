# !pip install google-search-results --upgrade
from serpapi import GoogleSearch
import nltk
import pandas as pd
import plotly.express as px
nltk.download('vader_lexicon')
from nltk.sentiment.vader import SentimentIntensityAnalyzer
import re
import time

def search_and_analyze(topic, max_results=200):
    # Replace with your SerpApi API key
    api_key = "922092b86e21e7bc5dc2633ea59cd93c29909177097345b175d0d694bc729ba4"

    all_results = []
    for start_index in range(0, max_results, 10):
        params = {
            "q": topic,
            "api_key": api_key,
            "num": 10,
            "start": start_index,
            # Add other parameters like location, device, etc. as needed
        }
        search = GoogleSearch(params)
        results = search.get_dict()
        all_results.extend(results.get("organic_results", []))
        time.sleep(1)

    if not all_results:
        print("No results found for the topic.")
        df = pd.DataFrame({'Text': [], 'Sentiment': [], 'Compound': []})
        return df, "Neutral",0,0,0

    text_data = []
    for item in all_results:
        text = item.get("snippet")
        if text:
            text = re.sub(r"http\S+", "", text)
            text = re.sub(r"#\S+", "", text)
            text_data.append(text)

    analyzer = SentimentIntensityAnalyzer()
    sentiment_scores = []
    for text in text_data:
        score = analyzer.polarity_scores(text)
        sentiment_scores.append(score)

    df = pd.DataFrame({'Text': text_data})
    df['Sentiment'] = ['Neutral' if score['compound'] > -0.5 and score['compound'] < 0.5 else
                               'Positive' if score['compound'] >= 0.5 else 'Negative'
                               for score in sentiment_scores]
    df['Compound'] = [score['compound'] for score in sentiment_scores]

    # Count sentiments
    num_positive = df['Sentiment'].value_counts().get('Positive', 0)
    num_negative = df['Sentiment'].value_counts().get('Negative', 0)
    num_neutral = df['Sentiment'].value_counts().get('Neutral', 0)


    positive_scores = []
    negative_scores = []
    neutral_scores = []

    for score in sentiment_scores:
        positive_scores.append(score['pos'])
        negative_scores.append(score['neg'])
        neutral_scores.append(score['neu'])

    avg_positive = sum(positive_scores) / len(positive_scores) if positive_scores else 0
    avg_negative = sum(negative_scores) / len(negative_scores) if positive_scores else 0
    avg_neutral = sum(neutral_scores) / len(neutral_scores) if positive_scores else 0

    if avg_positive > avg_negative and avg_positive > avg_neutral:
        overall_sentiment = "Positive"
    elif avg_negative > avg_positive and avg_negative > avg_neutral:
        overall_sentiment = "Negative"
    else:
        overall_sentiment = "Neutral"


    return df, overall_sentiment,num_positive, num_negative, num_neutral

topic = input("Enter a topic: ")
if "review" not in topic.lower():
   topic = topic + " review"

print(topic)

df, overall_sentiment,num_positive, num_negative, num_neutral= search_and_analyze(topic, max_results=200)
sentiments = ['Positive', 'Negative', 'Neutral']
counts = [num_positive, num_negative, num_neutral]
fig = px.bar(x=sentiments, y=counts, color=sentiments,
             color_discrete_map={'Positive': 'green', 'Negative': 'red', 'Neutral': 'blue'},
             title='Sentiment Analysis Results',
             labels={'x': 'Sentiment', 'y': 'Number of Reviews'})
fig.show()
# ----------df here show the table
print(df)
print("Overall Sentiment:", overall_sentiment)
print("Positive:", num_positive)
print("Negative:", num_negative)
print("Neutral:", num_neutral)
df.to_csv('sentiment_analysis_results.csv', index=False)